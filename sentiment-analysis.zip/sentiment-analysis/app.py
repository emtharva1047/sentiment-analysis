"""
app.py

Phase 11: Streamlit Deployment.

A production-facing UI wrapping the trained model + TF-IDF vectorizer,
giving non-technical stakeholders (e.g. a support/product manager) a way
to test sentiment predictions without touching code -- this is the
artifact that turns a notebook result into an actual usable business tool.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import joblib
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from text_cleaning import clean_text  # noqa: E402

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "best_model.pkl"
VECTORIZER_PATH = ROOT / "models" / "tfidf_vectorizer.pkl"
MODEL_NAME_PATH = ROOT / "models" / "best_model_name.txt"

EXAMPLE_REVIEWS = [
    "This product is absolutely amazing! Best purchase I've made all year.",
    "Terrible quality, arrived damaged and tasted awful. Would not recommend.",
    "Not bad, does what it says, decent value for the price.",
    "I was skeptical but this turned out to be wonderful, my whole family loves it.",
]


@st.cache_resource
def load_artifacts():
    if not MODEL_PATH.exists() or not VECTORIZER_PATH.exists():
        return None, None, None
    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    model_name = MODEL_NAME_PATH.read_text().strip() if MODEL_NAME_PATH.exists() else "Unknown"
    return model, vectorizer, model_name


def predict_sentiment(text: str, model, vectorizer) -> tuple[str, dict]:
    cleaned = clean_text(text)
    vector = vectorizer.transform([cleaned])
    prediction = model.predict(vector)[0]

    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(vector)[0]
        classes = model.classes_
        confidence = {cls: float(p) for cls, p in zip(classes, proba)}
    else:
        # LinearSVC has no predict_proba; use decision_function distance as a
        # pseudo-confidence, min-max scaled into [0, 1] for display purposes only.
        score = model.decision_function(vector)[0]
        pos_conf = 1 / (1 + pow(2.718281828, -score))
        confidence = {"positive": pos_conf, "negative": 1 - pos_conf}

    return prediction, confidence


def main():
    st.set_page_config(page_title="Sentiment Analysis", page_icon="🛒", layout="centered")

    st.title("🛒 E-Commerce Review Sentiment Analyzer")
    st.caption("Binary sentiment classification (Positive / Negative) for customer product reviews.")

    model, vectorizer, model_name = load_artifacts()

    if model is None:
        st.error(
            "No trained model found. Run `python src/train_models.py` first "
            "to generate `models/best_model.pkl` and `models/tfidf_vectorizer.pkl`."
        )
        st.stop()

    st.sidebar.header("About")
    st.sidebar.write(f"**Active model:** {model_name}")
    st.sidebar.write("**Feature extraction:** TF-IDF (unigrams + bigrams)")
    st.sidebar.write(
        "This app was built as part of an end-to-end NLP sentiment analysis "
        "project covering data collection, cleaning, EDA, feature engineering, "
        "model comparison, and deployment."
    )

    st.subheader("Try an example review")
    example = st.selectbox("Example reviews", ["-- Select an example --"] + EXAMPLE_REVIEWS)

    default_text = example if example != "-- Select an example --" else ""
    review_text = st.text_area("Or enter your own review text:", value=default_text, height=150,
                                placeholder="Type or paste a product review here...")

    if st.button("Analyze Sentiment", type="primary"):
        if not review_text or not review_text.strip():
            st.warning("Please enter some review text before analyzing.")
        elif len(review_text.strip()) < 3:
            st.warning("Review text is too short to analyze meaningfully.")
        else:
            prediction, confidence = predict_sentiment(review_text, model, vectorizer)

            col1, col2 = st.columns(2)
            with col1:
                emoji = "😊" if prediction == "positive" else "😞"
                color = "green" if prediction == "positive" else "red"
                st.markdown(f"### Predicted Sentiment: :{color}[{prediction.upper()}] {emoji}")
            with col2:
                st.metric("Confidence", f"{max(confidence.values()) * 100:.1f}%")

            fig = go.Figure(go.Bar(
                x=list(confidence.values()),
                y=list(confidence.keys()),
                orientation="h",
                marker_color=["#C62828" if k == "negative" else "#2E7D32" for k in confidence.keys()],
            ))
            fig.update_layout(title="Prediction Probability", xaxis_title="Probability",
                               xaxis_range=[0, 1], height=250, margin=dict(l=10, r=10, t=40, b=10))
            st.plotly_chart(fig, use_container_width=True)

            report_df = pd.DataFrame([{
                "review_text": review_text,
                "predicted_sentiment": prediction,
                "confidence_positive": confidence.get("positive", None),
                "confidence_negative": confidence.get("negative", None),
            }])
            st.download_button(
                "Download Prediction Report (CSV)",
                data=report_df.to_csv(index=False).encode("utf-8"),
                file_name="sentiment_prediction_report.csv",
                mime="text/csv",
            )

    st.divider()
    st.caption(
        "Model trained on customer product reviews. Predictions are probabilistic "
        "and should support, not replace, human review for high-stakes decisions."
    )


if __name__ == "__main__":
    main()
