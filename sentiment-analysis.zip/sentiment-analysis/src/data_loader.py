"""
data_loader.py

Responsible for loading the raw Amazon Fine Food Reviews dataset and
constructing the binary sentiment target variable used throughout this
project.

Design rationale
-----------------
Keeping data loading in its own module (rather than inline in a notebook)
means:
  1. The exact same loading/labeling logic is used in EDA, training, and
     the Streamlit app -- eliminating train/serve skew.
  2. It's independently unit-testable (see tests/test_data_loader.py,
     added in a later phase).
  3. It can be imported by any future script without copy-pasting logic.

Author: Sentiment Analysis Project
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Star ratings considered positive vs. negative. 3-star reviews are
# intentionally excluded -- see Phase 2 documentation for justification
# (ambiguous label, would inject noise into a binary classification task).
POSITIVE_SCORES: tuple[int, ...] = (4, 5)
NEGATIVE_SCORES: tuple[int, ...] = (1, 2)


class DataLoadError(Exception):
    """Raised when the raw dataset cannot be loaded or is malformed."""


def load_raw_reviews(csv_path: str | Path) -> pd.DataFrame:
    """Load the raw Amazon Fine Food Reviews CSV from disk.

    Args:
        csv_path: Path to the raw ``Reviews.csv`` file.

    Returns:
        A DataFrame with the original, unmodified columns.

    Raises:
        DataLoadError: If the file is missing or required columns are absent.
    """
    path = Path(csv_path)
    if not path.exists():
        raise DataLoadError(
            f"Raw data file not found at '{path}'. "
            "Download it from Kaggle ('snap/amazon-fine-food-reviews') "
            "and place it at data/raw/Reviews.csv."
        )

    logger.info("Loading raw reviews from %s", path)
    df = pd.read_csv(path)

    required_columns = {"Id", "ProductId", "UserId", "Score", "Summary", "Text"}
    missing = required_columns - set(df.columns)
    if missing:
        raise DataLoadError(f"Dataset is missing expected columns: {missing}")

    logger.info("Loaded %d rows, %d columns", df.shape[0], df.shape[1])
    return df


def build_binary_sentiment_label(df: pd.DataFrame, score_column: str = "Score") -> pd.DataFrame:
    """Construct a binary sentiment label from the numeric star rating.

    Mapping:
        4-5 stars -> "positive"
        1-2 stars -> "negative"
        3 stars   -> dropped (ambiguous; see Phase 2 rationale)

    Args:
        df: DataFrame containing a numeric star-rating column.
        score_column: Name of the column holding the 1-5 star rating.

    Returns:
        A copy of ``df`` filtered to remove neutral (3-star) rows, with a
        new ``sentiment`` column added ("positive" / "negative").

    Raises:
        DataLoadError: If the score column contains values outside 1-5.
    """
    if not df[score_column].between(1, 5).all():
        raise DataLoadError(
            f"Column '{score_column}' contains values outside the expected 1-5 range."
        )

    df = df.copy()
    before = len(df)

    df = df[df[score_column] != 3].copy()
    dropped = before - len(df)
    logger.info("Dropped %d neutral (3-star) rows out of %d total", dropped, before)

    df["sentiment"] = df[score_column].apply(
        lambda s: "positive" if s in POSITIVE_SCORES else "negative"
    )
    return df


def load_and_label_reviews(csv_path: str | Path) -> pd.DataFrame:
    """Convenience wrapper: load raw data and attach the binary sentiment label.

    Args:
        csv_path: Path to the raw ``Reviews.csv`` file.

    Returns:
        Labeled DataFrame ready for EDA / preprocessing.
    """
    raw_df = load_raw_reviews(csv_path)
    labeled_df = build_binary_sentiment_label(raw_df)
    return labeled_df


if __name__ == "__main__":
    # Quick manual smoke test when run directly:
    #   python src/data_loader.py
    default_path = Path(__file__).resolve().parent.parent / "data" / "raw" / "Reviews.csv"
    data = load_and_label_reviews(default_path)
    print(data["sentiment"].value_counts())
