"""
eda.py

Phase 5: Exploratory Text Analysis.

Generates all required visualizations and saves them to figures/.
Each plot is generated with a fixed, reproducible style so figures are
consistent across reruns (important when regenerating on the real dataset
before final submission).
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from wordcloud import WordCloud

sns.set_theme(style="whitegrid")
FIGSIZE = (9, 5)


def plot_sentiment_distribution(df: pd.DataFrame, out_dir: Path) -> None:
    plt.figure(figsize=FIGSIZE)
    order = df["sentiment"].value_counts().index
    ax = sns.countplot(data=df, x="sentiment", order=order, hue="sentiment",
                        palette={"positive": "#2E7D32", "negative": "#C62828"}, legend=False)
    for container in ax.containers:
        ax.bar_label(container)
    plt.title("Sentiment Class Distribution")
    plt.xlabel("Sentiment")
    plt.ylabel("Number of Reviews")
    plt.tight_layout()
    plt.savefig(out_dir / "01_sentiment_distribution.png", dpi=150)
    plt.close()


def plot_review_length_distribution(df: pd.DataFrame, out_dir: Path, text_col: str = "clean_text") -> None:
    df = df.copy()
    df["word_count"] = df[text_col].str.split().str.len()
    plt.figure(figsize=FIGSIZE)
    sns.histplot(data=df, x="word_count", hue="sentiment", bins=30, kde=True,
                 palette={"positive": "#2E7D32", "negative": "#C62828"}, element="step")
    plt.title("Review Length Distribution (words, post-cleaning)")
    plt.xlabel("Word Count")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(out_dir / "02_review_length_distribution.png", dpi=150)
    plt.close()


def _top_n_words(texts: pd.Series, n: int = 20) -> list[tuple[str, int]]:
    counter = Counter()
    for text in texts:
        counter.update(text.split())
    return counter.most_common(n)


def plot_top_words(df: pd.DataFrame, sentiment: str, out_dir: Path, filename: str,
                    text_col: str = "clean_text", n: int = 20) -> None:
    subset = df[df["sentiment"] == sentiment][text_col]
    top_words = _top_n_words(subset, n)
    words, counts = zip(*top_words)
    plt.figure(figsize=FIGSIZE)
    color = "#2E7D32" if sentiment == "positive" else "#C62828"
    sns.barplot(x=list(counts), y=list(words), color=color)
    plt.title(f"Top {n} Words in {sentiment.capitalize()} Reviews")
    plt.xlabel("Frequency")
    plt.tight_layout()
    plt.savefig(out_dir / filename, dpi=150)
    plt.close()


def plot_wordcloud(df: pd.DataFrame, sentiment: str, out_dir: Path, filename: str,
                    text_col: str = "clean_text") -> None:
    subset_text = " ".join(df[df["sentiment"] == sentiment][text_col])
    colormap = "Greens" if sentiment == "positive" else "Reds"
    wc = WordCloud(width=1000, height=500, background_color="white", colormap=colormap).generate(subset_text)
    plt.figure(figsize=(10, 5))
    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    plt.title(f"{sentiment.capitalize()} Reviews WordCloud")
    plt.tight_layout()
    plt.savefig(out_dir / filename, dpi=150)
    plt.close()


def plot_ngrams(df: pd.DataFrame, out_dir: Path, ngram_range: tuple[int, int],
                 filename: str, title: str, text_col: str = "clean_text", n: int = 15) -> None:
    vectorizer = CountVectorizer(ngram_range=ngram_range, max_features=2000)
    matrix = vectorizer.fit_transform(df[text_col])
    sums = matrix.sum(axis=0)
    freqs = [(word, sums[0, idx]) for word, idx in vectorizer.vocabulary_.items()]
    freqs = sorted(freqs, key=lambda x: x[1], reverse=True)[:n]
    words, counts = zip(*freqs)
    plt.figure(figsize=FIGSIZE)
    sns.barplot(x=list(counts), y=list(words), color="#1565C0")
    plt.title(title)
    plt.xlabel("Frequency")
    plt.tight_layout()
    plt.savefig(out_dir / filename, dpi=150)
    plt.close()


def plot_tfidf_top_terms(df: pd.DataFrame, out_dir: Path, text_col: str = "clean_text", n: int = 20) -> None:
    vectorizer = TfidfVectorizer(max_features=5000)
    matrix = vectorizer.fit_transform(df[text_col])
    mean_scores = matrix.mean(axis=0).A1
    terms = vectorizer.get_feature_names_out()
    top_idx = mean_scores.argsort()[::-1][:n]
    top_terms = [(terms[i], mean_scores[i]) for i in top_idx]
    words, scores = zip(*top_terms)
    plt.figure(figsize=FIGSIZE)
    sns.barplot(x=list(scores), y=list(words), color="#6A1B9A")
    plt.title(f"Top {n} Terms by Mean TF-IDF Score")
    plt.xlabel("Mean TF-IDF Score")
    plt.tight_layout()
    plt.savefig(out_dir / "10_tfidf_top_terms.png", dpi=150)
    plt.close()


def run_full_eda(df: pd.DataFrame, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    plot_sentiment_distribution(df, out_dir)
    plot_review_length_distribution(df, out_dir)
    plot_top_words(df, "positive", out_dir, "03_top_positive_words.png")
    plot_top_words(df, "negative", out_dir, "04_top_negative_words.png")
    plot_wordcloud(df, "positive", out_dir, "05_wordcloud_positive.png")
    plot_wordcloud(df, "negative", out_dir, "06_wordcloud_negative.png")
    plot_ngrams(df, out_dir, (2, 2), "07_bigrams.png", "Top Bigrams (All Reviews)")
    plot_ngrams(df, out_dir, (3, 3), "08_trigrams.png", "Top Trigrams (All Reviews)")
    plot_tfidf_top_terms(df, out_dir)
    print(f"All EDA figures saved to {out_dir}")


if __name__ == "__main__":
    processed_path = Path(__file__).resolve().parent.parent / "data" / "processed" / "cleaned_reviews.csv"
    figures_dir = Path(__file__).resolve().parent.parent / "figures"

    data = pd.read_csv(processed_path)
    data["clean_text"] = data["clean_text"].fillna("")
    run_full_eda(data, figures_dir)
