"""Builds notebooks/Sentiment_Analysis_End_to_End.ipynb by combining all pipeline
phases into a single narrated, executable notebook."""
import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

md("""# Sentiment Analysis on E-Commerce Product Reviews
### End-to-End NLP Pipeline: Data → Cleaning → EDA → Feature Extraction → Modeling → Evaluation → Business Insights → Deployment

**Note:** This notebook runs on a synthetic, template-generated stand-in dataset (`data/raw/Reviews.csv`)
so it executes fully without external downloads. Replace with the real **Amazon Fine Food Reviews**
dataset (Kaggle: `snap/amazon-fine-food-reviews`) before using these results for a report, resume, or interview.
""")

code("""import sys
sys.path.insert(0, '../src')
import pandas as pd
import warnings
warnings.filterwarnings('ignore')
pd.set_option('display.max_colwidth', 120)
""")

md("## Phase 2-3: Load Data & Construct Binary Sentiment Label")
code("""from data_loader import load_and_label_reviews

df = load_and_label_reviews('../data/raw/Reviews.csv')
print(df.shape)
df.head()
""")

md("## Phase 3: Data Understanding")
code("""from data_understanding import inspect_dataset

report = inspect_dataset(df)
print(report.to_markdown())
""")

md("""**Observations:**
- Class distribution reflects the typical positive skew of e-commerce reviews.
- Duplicate review text is checked separately from full-row duplicates, since spam/copy-paste
  reviews often share text but differ in metadata.
- Review length in words gives a baseline before cleaning; compare against the post-cleaning
  distribution in the EDA section below.
""")

md("## Phase 4: Text Cleaning")
code("""from text_cleaning import clean_dataframe

df_clean = clean_dataframe(df)
df_clean = df_clean.drop_duplicates(subset=['clean_text'])
df_clean[['Text', 'clean_text', 'sentiment']].sample(5, random_state=1)
""")

md("""**Why each step matters** (full detail in `src/text_cleaning.py` docstrings):
lowercasing normalizes case; HTML/URL/emoji removal strips non-linguistic noise; contraction
expansion happens *before* punctuation removal so negation isn't lost; negation words are merged
with the following token (`not_good`) instead of being dropped as stopwords, preserving polarity-flipping signal.
""")

code("df_clean.to_csv('../data/processed/cleaned_reviews.csv', index=False)")

md("## Phase 5: Exploratory Text Analysis")
code("""from eda import run_full_eda
from pathlib import Path

run_full_eda(df_clean, Path('../figures'))
""")

code("""import matplotlib.pyplot as plt
import matplotlib.image as mpimg

fig, axes = plt.subplots(1, 2, figsize=(16, 6))
axes[0].imshow(mpimg.imread('../figures/01_sentiment_distribution.png')); axes[0].axis('off')
axes[1].imshow(mpimg.imread('../figures/02_review_length_distribution.png')); axes[1].axis('off')
plt.tight_layout(); plt.show()
""")

code("""fig, axes = plt.subplots(1, 2, figsize=(16, 6))
axes[0].imshow(mpimg.imread('../figures/05_wordcloud_positive.png')); axes[0].axis('off'); axes[0].set_title('Positive')
axes[1].imshow(mpimg.imread('../figures/06_wordcloud_negative.png')); axes[1].axis('off'); axes[1].set_title('Negative')
plt.tight_layout(); plt.show()
""")

md("""**Business insight:** Positive reviews cluster around taste/quality/value language; negative
reviews cluster around spoilage/quality-defect language. **Technical insight:** vocabulary is
cleanly separable per class in this demo dataset (a known artifact of template generation) — on
real data expect more lexical overlap, which is exactly what makes classification non-trivial.
**Recommendation:** track these top terms over time in production as an early-warning signal.
""")

md("## Phase 6: Feature Extraction & Phase 7-8: Model Development + Evaluation")
code("""from train_models import (load_processed_data, compare_feature_extractors, get_candidate_models,
                            evaluate_model)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import joblib

import numpy as np

data = load_processed_data(Path('../data/processed/cleaned_reviews.csv'))
X_train_text, X_test_text, y_train, y_test = train_test_split(
    data['clean_text'], data['sentiment'], test_size=0.2, random_state=42, stratify=data['sentiment'])
# Coerce to plain numpy object arrays -- pandas' PyArrow-backed string dtype
# (default on CSV reads in newer pandas) breaks sklearn's internal fancy indexing.
y_train = pd.Series(np.asarray(y_train, dtype=object), index=y_train.index)
y_test = pd.Series(np.asarray(y_test, dtype=object), index=y_test.index)

fe_results = compare_feature_extractors(X_train_text, X_test_text, y_train.values, y_test.values)
pd.DataFrame(fe_results).T
""")

md("""**Feature extraction choice:** TF-IDF (unigrams + bigrams) is used going forward — it
down-weights globally common words and up-weights terms distinctive to a given review, is fully
interpretable (important for the business explainability goal from Phase 1), and needs no external
pretrained embedding files. See `src/train_models.py` module docstring for the full BoW vs.
TF-IDF vs. Word2Vec/GloVe/FastText vs. sentence-embedding comparison and trade-off discussion.
""")

code("""vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1, 2), min_df=2)
X_train = vectorizer.fit_transform(X_train_text)
X_test = vectorizer.transform(X_test_text)

all_metrics = []
trained_models = {}
for name, model in get_candidate_models().items():
    metrics, fitted, preds = evaluate_model(name, model, X_train, X_test, y_train.values, y_test.values)
    all_metrics.append(metrics)
    trained_models[name] = (fitted, preds)
    print(f"{name:25s} Acc={metrics['accuracy']:.4f}  F1={metrics['f1_score']:.4f}  "
          f"CV-F1={metrics['cv_f1_macro_mean']:.4f}")

comparison_df = pd.DataFrame([{k: v for k, v in m.items() if k not in ('confusion_matrix','classification_report')}
                                for m in all_metrics]).sort_values('f1_score', ascending=False)
comparison_df
""")

md("""**Metric choice rationale:** F1 score is used to select the best model because it balances
precision and recall under class imbalance — plain accuracy would be misleadingly high on a
skewed dataset (a model that always predicts "positive" still scores well on accuracy alone).
""")

code("""import seaborn as sns
from sklearn.metrics import confusion_matrix

best_name = comparison_df.iloc[0]['model']
best_model, best_preds = trained_models[best_name]
print(f"Best model: {best_name}")

cm = confusion_matrix(y_test, best_preds, labels=['negative', 'positive'])
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['negative','positive'],
            yticklabels=['negative','positive'])
plt.xlabel('Predicted'); plt.ylabel('Actual'); plt.title(f'Confusion Matrix - {best_name}')
plt.tight_layout(); plt.show()
""")

code("""from sklearn.metrics import classification_report
print(classification_report(y_test, best_preds))
""")

code("""joblib.dump(best_model, '../models/best_model.pkl')
joblib.dump(vectorizer, '../models/tfidf_vectorizer.pkl')
with open('../models/best_model_name.txt', 'w') as f:
    f.write(best_name)
print('Saved best model and vectorizer to ../models/')
""")

md("## Phase 9: Error Analysis")
code("""test_df = pd.DataFrame({'clean_text': X_test_text.values, 'true_label': y_test.values,
                          'predicted_label': best_preds})
test_df.to_csv('../reports/test_predictions_best_model.csv', index=False)

from error_analysis import run_error_analysis
errors = run_error_analysis(Path('../reports/test_predictions_best_model.csv'),
                              Path('../reports/error_analysis.csv'))
errors.head(10) if not errors.empty else "No errors on this run — see note above about synthetic data."
""")

md("## Phase 10: Business Insights")
code("""from business_insights import generate_business_report

data.attrs['synthetic'] = True
_ = generate_business_report(data, Path('../reports/phase10_business_insights.md'))
""")

md("""## Phase 11: Deployment

The trained model and vectorizer saved above are consumed directly by `app.py`
(Streamlit). Run from the project root with:

```bash
streamlit run app.py
```

See `reports/screenshot_01_home.png` through `screenshot_03_prediction_result.png` for the
running application, and the project README for the full usage guide.
""")

md("""## Summary

This notebook demonstrates the complete NLP lifecycle: business framing → data collection →
data understanding → cleaning → EDA → feature extraction → multi-model training and evaluation
→ error analysis → business insights → deployment. See `reports/` for the full metrics, error,
and business insight artifacts, and the project `README.md` for setup instructions.
""")

nb['cells'] = cells
with open('/home/claude/Sentiment-Analysis/notebooks/Sentiment_Analysis_End_to_End.ipynb', 'w') as f:
    nbf.write(nb, f)
print("Notebook written")
