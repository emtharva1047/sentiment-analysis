"""
business_insights.py

Phase 10: Business Insights.

Translates the statistical outputs of Phases 5-9 (top words, class balance,
error patterns) into an actionable business narrative -- the deliverable
stakeholders actually read, tying back to the ROI framing from Phase 1.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import pandas as pd


def top_words(texts: pd.Series, n: int = 15) -> list[str]:
    counter = Counter()
    for text in texts:
        counter.update(text.split())
    return [w for w, _ in counter.most_common(n)]


def generate_business_report(df: pd.DataFrame, out_path: Path) -> str:
    class_counts = df["sentiment"].value_counts()
    pct_positive = class_counts.get("positive", 0) / len(df) * 100
    pct_negative = class_counts.get("negative", 0) / len(df) * 100

    pos_words = top_words(df[df["sentiment"] == "positive"]["clean_text"])
    neg_words = top_words(df[df["sentiment"] == "negative"]["clean_text"])

    report = f"""# Phase 10 - Business Insights Report

## Overall Sentiment Health
- **{pct_positive:.1f}%** of analyzed reviews are positive, **{pct_negative:.1f}%** negative.
- This ratio should be tracked over time (weekly/monthly) as a leading indicator
  of customer satisfaction trend -- a sudden drop in positive share is an early
  warning signal worth investigating before it shows up in return-rate or churn data.

## Most Appreciated Themes (from top words in positive reviews)
{', '.join(pos_words)}

**Interpretation:** These recurring terms represent what customers consistently
value. Marketing and product teams should double down on messaging and product
attributes that reinforce these themes, and highlight them in listings/ads.

## Frequent Complaint Themes (from top words in negative reviews)
{', '.join(neg_words)}

**Interpretation:** These terms represent the most common language customers use
when dissatisfied. Product/quality teams should treat spikes in these terms as
triage signals -- e.g. repeated mentions of a specific quality issue across many
reviews for the same product ID is a stronger, earlier signal than waiting for
return-rate data to catch up.

## Recommended Actions
1. **Route high-negative-sentiment reviews to a priority support queue** for
   faster response -- unaddressed negative sentiment is a churn risk.
2. **Feed top complaint terms into the product roadmap review** on a recurring
   (e.g. monthly) cadence, not just when a metric alarm fires.
3. **Use top positive terms in marketing copy** and product descriptions, since
   they reflect the language customers themselves already use to describe value.
4. **Monitor sentiment ratio per product line**, not just in aggregate --
   aggregate sentiment can mask a single underperforming product dragging
   down an otherwise healthy category.
5. **Re-run this pipeline on a recurring schedule** (e.g. weekly) once in
   production, and track sentiment ratio as a time series metric on a dashboard.

## Caveat
This report was generated on {"synthetic demonstration data" if df.attrs.get("synthetic", True) else "the real dataset"}.
Re-run this script against the real Amazon Fine Food Reviews dataset (or your
production review stream) before using these specific themes/ratios in an
actual business decision.
"""
    out_path.write_text(report, encoding="utf-8")
    print(report)
    return report


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    processed_path = root / "data" / "processed" / "cleaned_reviews.csv"
    out_path = root / "reports" / "phase10_business_insights.md"

    data = pd.read_csv(processed_path)
    data["clean_text"] = data["clean_text"].fillna("")
    data.attrs["synthetic"] = True
    generate_business_report(data, out_path)
