"""
text_cleaning.py

Phase 4: Text Cleaning.

Each cleaning step below exists to remove a specific source of noise that
would otherwise inflate the vocabulary, dilute signal words, or bias the
model on artifacts (HTML, URLs) rather than genuine sentiment language.
Negation handling is done via a lightweight token-merging strategy
(e.g., "not good" -> "not_good") so downstream bag-of-words/TF-IDF models
don't lose the polarity flip that simple stopword removal would erase.
"""

from __future__ import annotations

import re
import string

import contractions
import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

STEMMER = PorterStemmer()
LEMMATIZER = WordNetLemmatizer()
STOPWORDS = set(stopwords.words("english"))

# Negation words are deliberately KEPT out of the stopword removal step,
# because dropping "not"/"no" flips a negative review's true meaning
# ("not good" would collapse to "good" after naive stopword removal).
NEGATION_WORDS = {"not", "no", "never", "n't", "cannot", "nor"}
STOPWORDS_MINUS_NEGATION = STOPWORDS - NEGATION_WORDS

HTML_TAG_RE = re.compile(r"<.*?>")
URL_RE = re.compile(r"https?://\S+|www\.\S+")
EMOJI_RE = re.compile(
    "["
    "\U0001F600-\U0001F64F"
    "\U0001F300-\U0001F5FF"
    "\U0001F680-\U0001F6FF"
    "\U0001F1E0-\U0001F1FF"
    "\U00002700-\U000027BF"
    "\U0001F900-\U0001F9FF"
    "\U00002600-\U000026FF"
    "]+",
    flags=re.UNICODE,
)
NUMBER_RE = re.compile(r"\d+")
MULTISPACE_RE = re.compile(r"\s+")


def to_lowercase(text: str) -> str:
    """Lowercase all text so 'Great' and 'great' are treated as the same token."""
    return text.lower()


def remove_html_tags(text: str) -> str:
    """Strip HTML artifacts (e.g. '<br />') common in scraped/exported review text."""
    return HTML_TAG_RE.sub(" ", text)


def remove_urls(text: str) -> str:
    """Remove URLs, which carry no sentiment signal and inflate the vocabulary with noise tokens."""
    return URL_RE.sub(" ", text)


def remove_emojis(text: str) -> str:
    """Remove emoji characters; classical BoW/TF-IDF models can't use them meaningfully."""
    return EMOJI_RE.sub(" ", text)


def expand_contractions(text: str) -> str:
    """Expand contractions ('don't' -> 'do not') BEFORE punctuation removal,
    otherwise the apostrophe is stripped first and 'dont' becomes an unrecognized token
    that loses its negation meaning entirely."""
    return contractions.fix(text)


def remove_punctuation(text: str) -> str:
    """Remove punctuation, which is not predictive for classical bag-of-words style models."""
    return text.translate(str.maketrans("", "", string.punctuation))


def remove_numbers(text: str) -> str:
    """Remove standalone digits (e.g. order numbers, quantities) that add noise, not sentiment."""
    return NUMBER_RE.sub(" ", text)


def remove_extra_spaces(text: str) -> str:
    """Collapse repeated whitespace introduced by the previous removal steps."""
    return MULTISPACE_RE.sub(" ", text).strip()


def tokenize(text: str) -> list[str]:
    """Split cleaned text into word tokens."""
    return text.split()


def handle_negation(tokens: list[str]) -> list[str]:
    """Merge a negation word with the following token (e.g. ['not','good'] -> ['not_good']).

    Why: naive stopword removal deletes 'not', silently flipping 'not good'
    into 'good' -- a critical, well-known failure mode in sentiment analysis.
    Merging preserves the polarity-flipping signal as a single feature.
    """
    merged: list[str] = []
    skip_next = False
    for i, token in enumerate(tokens):
        if skip_next:
            skip_next = False
            continue
        if token in NEGATION_WORDS and i + 1 < len(tokens):
            merged.append(f"{token}_{tokens[i + 1]}")
            skip_next = True
        else:
            merged.append(token)
    return merged


def remove_stopwords(tokens: list[str]) -> list[str]:
    """Remove common low-information words (the, is, at...), excluding negation words
    (already consumed by handle_negation, but kept safe here too)."""
    return [t for t in tokens if t not in STOPWORDS_MINUS_NEGATION]


def stem_tokens(tokens: list[str]) -> list[str]:
    """Reduce words to their root form via Porter stemming (fast, rule-based, some over-stemming)."""
    return [STEMMER.stem(t) for t in tokens]


def lemmatize_tokens(tokens: list[str]) -> list[str]:
    """Reduce words to their dictionary root form via WordNet lemmatization
    (slower than stemming but linguistically accurate -- 'better' -> 'good' vs stemmer's 'better' -> 'better')."""
    return [LEMMATIZER.lemmatize(t) for t in tokens]


def clean_text(text: str, use_lemmatization: bool = True) -> str:
    """Run the full cleaning pipeline on a single review string.

    Pipeline order matters:
      lowercase -> strip HTML -> strip URLs -> strip emojis -> expand contractions
      -> remove punctuation -> remove numbers -> collapse spaces -> tokenize
      -> merge negations -> remove stopwords -> stem/lemmatize -> rejoin

    Args:
        text: Raw review text.
        use_lemmatization: If True, lemmatize; otherwise, stem. Lemmatization
            is the project default (see Phase 4 write-up for the trade-off).

    Returns:
        Cleaned, space-joined text ready for vectorization.
    """
    if not isinstance(text, str):
        return ""

    text = to_lowercase(text)
    text = remove_html_tags(text)
    text = remove_urls(text)
    text = remove_emojis(text)
    text = expand_contractions(text)
    text = remove_punctuation(text)
    text = remove_numbers(text)
    text = remove_extra_spaces(text)

    tokens = tokenize(text)
    tokens = handle_negation(tokens)
    tokens = remove_stopwords(tokens)
    tokens = lemmatize_tokens(tokens) if use_lemmatization else stem_tokens(tokens)

    return " ".join(tokens)


def clean_dataframe(df: pd.DataFrame, text_column: str = "Text",
                     output_column: str = "clean_text") -> pd.DataFrame:
    """Apply `clean_text` to every row of a DataFrame and drop rows that
    become empty after cleaning (pure noise, e.g. a review that was only a URL)."""
    df = df.copy()
    df[output_column] = df[text_column].apply(clean_text)
    before = len(df)
    df = df[df[output_column].str.strip() != ""]
    dropped = before - len(df)
    print(f"Dropped {dropped} rows that became empty after cleaning")
    return df


if __name__ == "__main__":
    from pathlib import Path

    from data_loader import load_and_label_reviews

    raw_path = Path(__file__).resolve().parent.parent / "data" / "raw" / "Reviews.csv"
    processed_path = Path(__file__).resolve().parent.parent / "data" / "processed" / "cleaned_reviews.csv"

    df = load_and_label_reviews(raw_path)
    df = clean_dataframe(df)
    df = df.drop_duplicates(subset=["clean_text"])  # de-dupe on cleaned text (Phase 3 finding)

    processed_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(processed_path, index=False)
    print(f"Cleaned dataset written to {processed_path} -- shape: {df.shape}")
    print(df[["Text", "clean_text", "sentiment"]].head(5).to_string())
