"""
data_understanding.py

Phase 3: Text Data Understanding.

Produces a factual, non-visual inventory of the raw dataset: shape,
missing values, duplicates, class balance, review length statistics,
and vocabulary size. This runs BEFORE any cleaning or visualization
so that all later decisions are grounded in verified facts about the
data, not assumptions.

Usage:
    python src/data_understanding.py
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from data_loader import load_and_label_reviews

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


@dataclass
class DataInventoryReport:
    """Structured summary of a Phase 3 data understanding pass.

    Attributes:
        n_rows: Total row count after label construction.
        n_columns: Total column count.
        missing_values: Per-column count of missing/null values.
        n_exact_duplicate_rows: Fully duplicated rows across all columns.
        n_duplicate_text_rows: Rows with duplicate review ``Text`` values
            (a stronger signal of spam/copy-paste reviews than full-row
            duplicates, since metadata can differ while text is copied).
        class_distribution: Count and percentage of each sentiment class.
        review_length_word_stats: Summary statistics (min/mean/median/max)
            of review length in words.
        vocabulary_size: Count of unique whitespace-delimited tokens across
            the corpus (a rough, pre-cleaning estimate; refined in Phase 4).
    """

    n_rows: int
    n_columns: int
    missing_values: dict[str, int] = field(default_factory=dict)
    n_exact_duplicate_rows: int = 0
    n_duplicate_text_rows: int = 0
    class_distribution: dict[str, dict[str, float]] = field(default_factory=dict)
    review_length_word_stats: dict[str, float] = field(default_factory=dict)
    vocabulary_size: int = 0

    def to_markdown(self) -> str:
        """Render the report as a Markdown string for inclusion in reports/."""
        lines = ["# Phase 3 - Data Understanding Report", ""]
        lines.append(f"- **Rows:** {self.n_rows:,}")
        lines.append(f"- **Columns:** {self.n_columns}")
        lines.append("")
        lines.append("## Missing Values")
        for col, count in self.missing_values.items():
            if count > 0:
                lines.append(f"- `{col}`: {count:,} missing ({count / self.n_rows:.2%})")
        lines.append("")
        lines.append("## Duplicates")
        lines.append(f"- Exact duplicate rows: {self.n_exact_duplicate_rows:,}")
        lines.append(f"- Duplicate review text: {self.n_duplicate_text_rows:,}")
        lines.append("")
        lines.append("## Class Distribution")
        for label, stats in self.class_distribution.items():
            lines.append(f"- **{label}**: {stats['count']:,.0f} ({stats['pct']:.2f}%)")
        lines.append("")
        lines.append("## Review Length (words)")
        for stat, value in self.review_length_word_stats.items():
            lines.append(f"- {stat}: {value:.2f}")
        lines.append("")
        lines.append(f"## Vocabulary Size (raw, pre-cleaning)\n- {self.vocabulary_size:,} unique tokens")
        return "\n".join(lines)


def inspect_dataset(df: pd.DataFrame, text_column: str = "Text") -> DataInventoryReport:
    """Run the full Phase 3 inspection over a labeled DataFrame.

    Args:
        df: Labeled DataFrame (output of ``load_and_label_reviews``).
        text_column: Name of the column containing review text.

    Returns:
        A populated ``DataInventoryReport``.
    """
    n_rows, n_columns = df.shape

    missing_values = df.isnull().sum().to_dict()

    n_exact_duplicate_rows = int(df.duplicated().sum())
    n_duplicate_text_rows = int(df.duplicated(subset=[text_column]).sum())

    class_counts = df["sentiment"].value_counts()
    class_distribution = {
        label: {"count": float(count), "pct": float(count / n_rows * 100)}
        for label, count in class_counts.items()
    }

    word_counts = df[text_column].astype(str).str.split().str.len()
    review_length_word_stats = {
        "min": float(word_counts.min()),
        "mean": float(word_counts.mean()),
        "median": float(word_counts.median()),
        "max": float(word_counts.max()),
        "std": float(word_counts.std()),
    }

    all_tokens = set()
    for tokens in df[text_column].astype(str).str.lower().str.split():
        all_tokens.update(tokens)
    vocabulary_size = len(all_tokens)

    report = DataInventoryReport(
        n_rows=n_rows,
        n_columns=n_columns,
        missing_values=missing_values,
        n_exact_duplicate_rows=n_exact_duplicate_rows,
        n_duplicate_text_rows=n_duplicate_text_rows,
        class_distribution=class_distribution,
        review_length_word_stats=review_length_word_stats,
        vocabulary_size=vocabulary_size,
    )
    return report


if __name__ == "__main__":
    raw_path = Path(__file__).resolve().parent.parent / "data" / "raw" / "Reviews.csv"
    report_path = Path(__file__).resolve().parent.parent / "reports" / "phase3_data_understanding.md"

    labeled_df = load_and_label_reviews(raw_path)
    inventory = inspect_dataset(labeled_df)

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(inventory.to_markdown(), encoding="utf-8")

    print(inventory.to_markdown())
    logger.info("Report written to %s", report_path)
