import time
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1200, "height": 900})
    page.goto("http://localhost:8504", wait_until="networkidle", timeout=30000)
    time.sleep(2)
    page.screenshot(path="/home/claude/Sentiment-Analysis/reports/screenshot_01_home.png", full_page=True)

    # Type directly into the text area (more reliable than driving the selectbox)
    textarea = page.locator("textarea").first
    textarea.click()
    textarea.fill("This product is absolutely amazing! Best purchase I've made all year, "
                   "fantastic quality and fast shipping.")
    time.sleep(1)
    page.screenshot(path="/home/claude/Sentiment-Analysis/reports/screenshot_02_example_selected.png", full_page=True)

    page.get_by_role("button", name="Analyze Sentiment").click()
    try:
        page.wait_for_selector("text=Confidence", timeout=15000)
    except Exception as e:
        print("Selector wait failed, falling back to fixed sleep:", e)
    time.sleep(3)
    page.screenshot(path="/home/claude/Sentiment-Analysis/reports/screenshot_03_prediction_result.png", full_page=True)

    browser.close()
    print("Screenshots captured")
