"""
train_models.py

Phase 6: Feature Extraction
Phase 7: Model Development
Phase 8: Model Evaluation

Why TF-IDF over Bag of Words / Word2Vec / GloVe / FastText / sentence
embeddings for THIS project:
------------------------------------------------------------------------
- Bag of Words: simplest baseline, but treats every word as equally
  important -- "the" and "disgusting" get equal weight before
  normalization. We report it as a baseline comparison, not the final choice.
- TF-IDF: down-weights common words across the corpus and up-weights
  words that are distinctive to a given review, which is exactly the
  signal sentiment classification needs. Cheap to compute, no external
  pretrained files, fully interpretable feature weights (critical for
  the business explainability requirement from Phase 1). CHOSEN as the
  primary feature representation for our classical ML models.
- Word2Vec / GloVe / FastText: pretrained dense embeddings capture
  semantic similarity, but averaging word vectors to a document vector
  loses word-order and negation signal (which we specifically preserved
  with negation-merging in Phase 4), and requires downloading large
  external files -- unnecessary complexity for a classical-ML-first project.
- Sentence embeddings (e.g. SBERT): best raw accuracy potential, but a
  transformer dependency is heavy for a project meant to demonstrate the
  full classical NLP lifecycle, and comes at the cost of interpretability.
  Flagged as a "Future Enhancement" (Phase 9/13).

We still train an optional deep learning model (calibrated logistic
regression on top of the TF-IDF matrix substitutes for a lightweight
neural baseline in this environment) for comparison purposes; a full
LSTM/BiLSTM is documented as a future extension requiring GPU compute
beyond this project's scope.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC

RANDOM_STATE = 42


def load_processed_data(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["clean_text"] = df["clean_text"].fillna("")
    return df


def compare_feature_extractors(X_train_text: pd.Series, X_test_text: pd.Series,
                                y_train: np.ndarray, y_test: np.ndarray) -> dict:
    """Fit a quick Logistic Regression on BoW vs TF-IDF to empirically justify
    the Phase 6 recommendation, rather than asserting it without evidence."""
    results = {}
    for name, vectorizer in [
        ("BagOfWords", CountVectorizer(max_features=8000, ngram_range=(1, 1))),
        ("TF-IDF", TfidfVectorizer(max_features=8000, ngram_range=(1, 2))),
    ]:
        Xtr = vectorizer.fit_transform(X_train_text)
        Xte = vectorizer.transform(X_test_text)
        clf = LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
        clf.fit(Xtr, y_train)
        preds = clf.predict(Xte)
        results[name] = {
            "accuracy": accuracy_score(y_test, preds),
            "f1": f1_score(y_test, preds, pos_label="positive"),
        }
    return results


def get_candidate_models() -> dict:
    """Return the full model comparison suite required by Phase 7."""
    return {
        "Naive Bayes": MultinomialNB(),
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE, class_weight="balanced"),
        "Support Vector Machine": LinearSVC(random_state=RANDOM_STATE, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE, class_weight="balanced", n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
    }


def evaluate_model(name: str, model, X_train, X_test, y_train, y_test, X_train_full=None) -> dict:
    start = time.time()
    model.fit(X_train, y_train)
    train_time = time.time() - start

    preds = model.predict(X_test)

    # ROC-AUC needs probability/decision scores; not every model exposes predict_proba.
    try:
        if hasattr(model, "predict_proba"):
            scores = model.predict_proba(X_test)[:, list(model.classes_).index("positive")]
        else:
            scores = model.decision_function(X_test)
        auc = roc_auc_score((y_test == "positive").astype(int), scores)
    except Exception:
        auc = None

    # y_train is coerced to a plain numpy object array before cross-validation:
    # pandas' newer PyArrow-backed string dtype (from CSV reads) breaks sklearn's
    # internal fancy-indexing in some environments, so we avoid relying on it here.
    y_train_np = np.asarray(y_train, dtype=object)
    cv_scores = cross_val_score(model, X_train, y_train_np, cv=5, scoring="f1_macro", n_jobs=-1)

    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, preds),
        "precision": precision_score(y_test, preds, pos_label="positive"),
        "recall": recall_score(y_test, preds, pos_label="positive"),
        "f1_score": f1_score(y_test, preds, pos_label="positive"),
        "roc_auc": auc,
        "cv_f1_macro_mean": float(cv_scores.mean()),
        "cv_f1_macro_std": float(cv_scores.std()),
        "train_time_seconds": train_time,
        "confusion_matrix": confusion_matrix(y_test, preds, labels=["negative", "positive"]).tolist(),
        "classification_report": classification_report(y_test, preds, output_dict=True),
    }
    return metrics, model, preds


def main():
    root = Path(__file__).resolve().parent.parent
    processed_path = root / "data" / "processed" / "cleaned_reviews.csv"
    models_dir = root / "models"
    reports_dir = root / "reports"
    models_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    df = load_processed_data(processed_path)
    X_train_text, X_test_text, y_train, y_test = train_test_split(
        df["clean_text"], df["sentiment"], test_size=0.2, random_state=RANDOM_STATE, stratify=df["sentiment"]
    )
    # Coerce to plain numpy object arrays -- see note in evaluate_model() about
    # PyArrow-backed pandas string dtypes breaking sklearn's internal indexing.
    y_train = pd.Series(np.asarray(y_train, dtype=object), index=y_train.index)
    y_test = pd.Series(np.asarray(y_test, dtype=object), index=y_test.index)

    # ---- Phase 6: Feature Extraction comparison ----
    fe_comparison = compare_feature_extractors(X_train_text, X_test_text, y_train.values, y_test.values)
    print("Feature extraction comparison (Logistic Regression probe):")
    print(json.dumps(fe_comparison, indent=2))

    # Final chosen vectorizer: TF-IDF with unigrams+bigrams (captures short phrases
    # like "not_good" negation tokens and "highly recommend" as single features)
    vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1, 2), min_df=2)
    X_train = vectorizer.fit_transform(X_train_text)
    X_test = vectorizer.transform(X_test_text)
    joblib.dump(vectorizer, models_dir / "tfidf_vectorizer.pkl")

    # ---- Phase 7 + 8: Train & evaluate every model ----
    all_metrics = []
    trained_models = {}
    test_predictions = {}

    for name, model in get_candidate_models().items():
        print(f"\nTraining {name}...")
        metrics, fitted_model, preds = evaluate_model(name, model, X_train, X_test, y_train.values, y_test.values)
        all_metrics.append(metrics)
        trained_models[name] = fitted_model
        test_predictions[name] = preds
        print(f"  Accuracy={metrics['accuracy']:.4f}  F1={metrics['f1_score']:.4f}  "
              f"CV-F1(macro)={metrics['cv_f1_macro_mean']:.4f}")

    # Select best model by F1 score (justified in Phase 8 write-up: F1 balances
    # precision/recall under class imbalance, more informative than raw accuracy)
    best = max(all_metrics, key=lambda m: m["f1_score"])
    best_name = best["model"]
    best_model = trained_models[best_name]
    print(f"\nBest model by F1 score: {best_name} (F1={best['f1_score']:.4f})")

    joblib.dump(best_model, models_dir / "best_model.pkl")
    with open(models_dir / "best_model_name.txt", "w") as f:
        f.write(best_name)

    # Save full comparison table
    comparison_df = pd.DataFrame([
        {k: v for k, v in m.items() if k not in ("confusion_matrix", "classification_report")}
        for m in all_metrics
    ])
    comparison_df = comparison_df.sort_values("f1_score", ascending=False)
    comparison_df.to_csv(reports_dir / "model_comparison.csv", index=False)
    print("\n=== Model Comparison Table ===")
    print(comparison_df.to_string(index=False))

    with open(reports_dir / "model_metrics_full.json", "w") as f:
        json.dump({"feature_extraction_comparison": fe_comparison, "models": all_metrics,
                    "best_model": best_name}, f, indent=2, default=str)

    # Save test set + predictions of the best model for Phase 9 error analysis
    test_df = pd.DataFrame({
        "clean_text": X_test_text.values,
        "true_label": y_test.values,
        "predicted_label": test_predictions[best_name],
    })
    test_df.to_csv(reports_dir / "test_predictions_best_model.csv", index=False)

    print(f"\nArtifacts saved: models/best_model.pkl, models/tfidf_vectorizer.pkl, "
          f"reports/model_comparison.csv, reports/test_predictions_best_model.csv")


if __name__ == "__main__":
    main()
