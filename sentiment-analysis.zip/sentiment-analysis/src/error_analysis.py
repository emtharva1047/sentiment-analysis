"""
error_analysis.py

Phase 9: Error Analysis.

Identifies misclassified reviews from the best model's test predictions
and categorizes likely causes. On the synthetic demo dataset used to
build this pipeline, misclassifications are expected to be rare/absent
because the templated text is artificially separable -- this script is
written to degrade gracefully in that case, and to produce meaningful
output once run on the real, messier Amazon Fine Food Reviews data.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

NEGATION_MARKERS = ("not_", "no_", "never_", "cannot_", "nor_")
SARCASM_HINT_WORDS = {"yeah", "sure", "totally", "wow", "great job", "just what i needed"}


def categorize_error(text: str) -> str:
    """Heuristically tag a likely cause of misclassification for manual review.

    This is intentionally a heuristic, explainable rule set (not a model)
    because error analysis should be human-auditable -- the point is to
    guide future preprocessing/modeling decisions, not to auto-classify errors.
    """
    lower = text.lower()
    if any(marker in lower for marker in NEGATION_MARKERS):
        return "negation_present"
    if any(hint in lower for hint in SARCASM_HINT_WORDS):
        return "possible_sarcasm"
    if len(lower.split()) <= 3:
        return "very_short_review_low_signal"
    if ("good" in lower and "bad" in lower) or ("love" in lower and "hate" in lower):
        return "mixed_sentiment_signals"
    return "unclear_/_other"


def run_error_analysis(predictions_path: Path, output_path: Path) -> pd.DataFrame:
    df = pd.read_csv(predictions_path)
    errors = df[df["true_label"] != df["predicted_label"]].copy()

    if errors.empty:
        print("No misclassifications found on this run's test set.")
        print("This is expected on the synthetic template-based dataset, since its "
              "vocabulary is artificially separable between classes. On the real "
              "Amazon Fine Food Reviews data, expect a non-trivial error rate driven "
              "by sarcasm, mixed sentiment, and subtle negation -- rerun this script "
              "after Phase 7 training on the real data to get a genuine error report.")
        summary = pd.DataFrame(columns=["clean_text", "true_label", "predicted_label", "likely_cause"])
        summary.to_csv(output_path, index=False)
        return summary

    errors["likely_cause"] = errors["clean_text"].apply(categorize_error)
    error_summary = errors["likely_cause"].value_counts()
    print("Error cause breakdown:")
    print(error_summary)

    errors.to_csv(output_path, index=False)
    print(f"\n{len(errors)} misclassified reviews out of {len(df)} "
          f"({len(errors) / len(df):.2%} error rate) saved to {output_path}")
    return errors


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    predictions_path = root / "reports" / "test_predictions_best_model.csv"
    output_path = root / "reports" / "error_analysis.csv"
    run_error_analysis(predictions_path, output_path)
