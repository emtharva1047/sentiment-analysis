"""
generate_synthetic_dataset.py

IMPORTANT — READ BEFORE USING RESULTS ON A RESUME:
----------------------------------------------------
This script generates a SYNTHETIC stand-in dataset with the exact same
schema as the real "Amazon Fine Food Reviews" dataset (Kaggle:
snap/amazon-fine-food-reviews). It exists ONLY so that every phase of
this project's pipeline can be demonstrated end-to-end without requiring
network access to Kaggle from this environment.

Before publishing this project (GitHub, resume, interview), you MUST:
  1. Download the real Reviews.csv (see Phase 2 instructions).
  2. Replace data/raw/Reviews.csv with the real file.
  3. Re-run every phase's script (they are schema-compatible and will
     work identically on the real data).
  4. Use the numbers produced from the REAL data in your report/PPT/README.

Using synthetic numbers as if they were real results would misrepresent
your project's evaluation.
"""

from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import pandas as pd

random.seed(42)
np.random.seed(42)

POSITIVE_TEMPLATES = [
    "This {product} is absolutely {pos_adj}! I've been buying it for months and it never disappoints.",
    "Great {product}, tastes {pos_adj} and arrived {pos_delivery}. Will definitely order again.",
    "My family loves this {product}. It's {pos_adj} and the price is fair for the quality.",
    "Excellent {product}! Not {neg_adj} at all like some other brands, very {pos_adj}.",
    "I was skeptical at first but this {product} turned out to be {pos_adj}. Highly recommend!",
    "Best {product} I've tried. {pos_adj} flavor, {pos_delivery} shipping, will buy again for sure.",
    "Five stars, this {product} is {pos_adj} and my kids love it too.",
    "Really {pos_adj} quality for the price, the packaging was also {pos_delivery}.",
    "I can't believe how {pos_adj} this {product} is, exceeded my expectations completely.",
    "Perfect {product} for our household, {pos_adj} taste and never {neg_adj}.",
]

NEGATIVE_TEMPLATES = [
    "This {product} was extremely {neg_adj}, I would not recommend it to anyone.",
    "Terrible {product}, tasted {neg_adj} and arrived {neg_delivery}. Waste of money.",
    "I was disappointed, the {product} is {neg_adj} and not worth the price at all.",
    "Not {pos_adj} at all, actually quite {neg_adj}. Will not be ordering again.",
    "The {product} arrived {neg_delivery} and tasted {neg_adj}, very disappointing purchase.",
    "Worst {product} I've ever bought, {neg_adj} quality and poor packaging.",
    "One star, this {product} is {neg_adj} and made my family sick.",
    "Really {neg_adj} experience, the {product} was nothing like described, {neg_delivery} too.",
    "I regret buying this {product}, it's {neg_adj} and overpriced for what you get.",
    "Avoid this {product}, {neg_adj} taste and it wasn't even {pos_adj} like the reviews claimed.",
]

PRODUCTS = ["coffee", "granola bar", "olive oil", "green tea", "protein powder", "dog treats",
            "chocolate", "peanut butter", "cereal", "hot sauce", "pasta", "honey",
            "trail mix", "cookies", "spice blend"]
POS_ADJ = ["delicious", "amazing", "wonderful", "fantastic", "fresh", "great", "excellent", "fabulous"]
NEG_ADJ = ["stale", "bland", "awful", "disgusting", "terrible", "bad", "moldy", "artificial"]
POS_DELIVERY = ["quickly", "in perfect condition", "right on time", "well packaged"]
NEG_DELIVERY = ["late", "damaged", "in a crushed box", "after a long delay"]

HTML_NOISE = ["<br />", "<br/>", "&nbsp;", "<p>", "</p>"]
URL_NOISE = ["Check reviews at http://example.com/reviews", "See http://amzn.example/product123"]


def _inject_noise(text: str, rng: random.Random) -> str:
    """Randomly inject HTML tags / URLs / extra whitespace to mimic real-world messiness."""
    if rng.random() < 0.15:
        text += " " + rng.choice(HTML_NOISE)
    if rng.random() < 0.08:
        text += " " + rng.choice(URL_NOISE)
    if rng.random() < 0.10:
        text = text.replace(" ", "  ", 1)  # double space somewhere
    if rng.random() < 0.05:
        text += " :) " if rng.random() < 0.5 else " :( "
    return text


def generate_review(sentiment: str, rng: random.Random) -> str:
    template = rng.choice(POSITIVE_TEMPLATES if sentiment == "positive" else NEGATIVE_TEMPLATES)
    text = template.format(
        product=rng.choice(PRODUCTS),
        pos_adj=rng.choice(POS_ADJ),
        neg_adj=rng.choice(NEG_ADJ),
        pos_delivery=rng.choice(POS_DELIVERY),
        neg_delivery=rng.choice(NEG_DELIVERY),
    )
    # Occasionally append a second sentence for length variety
    if rng.random() < 0.4:
        extra_template = rng.choice(POSITIVE_TEMPLATES if sentiment == "positive" else NEGATIVE_TEMPLATES)
        text += " " + extra_template.format(
            product=rng.choice(PRODUCTS), pos_adj=rng.choice(POS_ADJ), neg_adj=rng.choice(NEG_ADJ),
            pos_delivery=rng.choice(POS_DELIVERY), neg_delivery=rng.choice(NEG_DELIVERY),
        )
    return _inject_noise(text, rng)


def generate_dataset(n_rows: int = 4000, positive_ratio: float = 0.76) -> pd.DataFrame:
    """Generate a synthetic dataset matching the real schema, including a
    realistic ~76/24 positive/negative class imbalance (typical of real
    Amazon review distributions) and a small slice of neutral (3-star)
    rows to be dropped downstream, exactly like the real data.
    """
    rng = random.Random(42)
    rows = []
    n_neutral = int(n_rows * 0.10)
    n_labeled = n_rows - n_neutral
    n_positive = int(n_labeled * positive_ratio)
    n_negative = n_labeled - n_positive

    for i in range(n_positive):
        rows.append({"Score": rng.choice([4, 5]), "sentiment_source": "positive",
                     "Text": generate_review("positive", rng)})
    for i in range(n_negative):
        rows.append({"Score": rng.choice([1, 2]), "sentiment_source": "negative",
                     "Text": generate_review("negative", rng)})
    for i in range(n_neutral):
        base = rng.choice(POSITIVE_TEMPLATES if rng.random() < 0.5 else NEGATIVE_TEMPLATES)
        text = base.format(product=rng.choice(PRODUCTS), pos_adj=rng.choice(POS_ADJ),
                            neg_adj=rng.choice(NEG_ADJ), pos_delivery=rng.choice(POS_DELIVERY),
                            neg_delivery=rng.choice(NEG_DELIVERY))
        rows.append({"Score": 3, "sentiment_source": "neutral", "Text": _inject_noise(text, rng)})

    rng.shuffle(rows)
    df = pd.DataFrame(rows)
    df.insert(0, "Id", range(1, len(df) + 1))
    df["ProductId"] = [f"B{rng.randint(100000, 999999)}" for _ in range(len(df))]
    df["UserId"] = [f"U{rng.randint(10000, 99999)}" for _ in range(len(df))]
    df["ProfileName"] = [f"Customer{rng.randint(1, 5000)}" for _ in range(len(df))]
    df["HelpfulnessNumerator"] = np.random.poisson(1.2, size=len(df))
    df["HelpfulnessDenominator"] = df["HelpfulnessNumerator"] + np.random.poisson(0.8, size=len(df))
    df["Time"] = np.random.randint(1230768000, 1609459200, size=len(df))  # 2009-2021 range
    df["Summary"] = df["Text"].str.split(".").str[0].str.slice(0, 40)
    df = df.drop(columns=["sentiment_source"])
    df = df[["Id", "ProductId", "UserId", "ProfileName", "HelpfulnessNumerator",
             "HelpfulnessDenominator", "Score", "Time", "Summary", "Text"]]
    return df


if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent.parent / "data" / "raw" / "Reviews.csv"
    dataset = generate_dataset(n_rows=4000)
    dataset.to_csv(out_path, index=False)
    print(f"Synthetic dataset written to {out_path} -- shape: {dataset.shape}")
    print(dataset["Score"].value_counts().sort_index())
