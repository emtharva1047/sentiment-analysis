"""Unit tests for src/text_cleaning.py"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from text_cleaning import (  # noqa: E402
    clean_text,
    expand_contractions,
    handle_negation,
    remove_html_tags,
    remove_urls,
    to_lowercase,
)


def test_to_lowercase():
    assert to_lowercase("Great Product") == "great product"


def test_remove_html_tags():
    assert remove_html_tags("Great product<br />really enjoyed it").strip() == "Great product really enjoyed it"


def test_remove_urls():
    result = remove_urls("Check it out at http://example.com/product")
    assert "http" not in result


def test_expand_contractions():
    assert "do not" in expand_contractions("I don't like this")


def test_handle_negation_merges_adjacent_tokens():
    tokens = ["not", "good", "at", "all"]
    merged = handle_negation(tokens)
    assert "not_good" in merged


def test_clean_text_end_to_end_removes_noise():
    raw = "This was NOT good!! <br /> Check http://x.com 123"
    cleaned = clean_text(raw)
    assert "http" not in cleaned
    assert "123" not in cleaned
    assert "not_good" in cleaned


def test_clean_text_handles_non_string_gracefully():
    assert clean_text(None) == ""
    assert clean_text(float("nan")) == ""


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
