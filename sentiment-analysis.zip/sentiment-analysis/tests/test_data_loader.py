"""Unit tests for src/data_loader.py"""
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from data_loader import DataLoadError, build_binary_sentiment_label  # noqa: E402


def _sample_df():
    return pd.DataFrame({
        "Id": [1, 2, 3, 4, 5],
        "Score": [5, 4, 3, 2, 1],
        "Text": ["great", "good", "ok", "bad", "terrible"],
    })


def test_binary_label_drops_neutral_rows():
    df = build_binary_sentiment_label(_sample_df())
    assert 3 not in df["Score"].values
    assert len(df) == 4


def test_binary_label_mapping_correct():
    df = build_binary_sentiment_label(_sample_df())
    assert set(df[df["Score"].isin([4, 5])]["sentiment"]) == {"positive"}
    assert set(df[df["Score"].isin([1, 2])]["sentiment"]) == {"negative"}


def test_binary_label_raises_on_invalid_scores():
    bad_df = pd.DataFrame({"Id": [1], "Score": [7], "Text": ["x"]})
    with pytest.raises(DataLoadError):
        build_binary_sentiment_label(bad_df)


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
