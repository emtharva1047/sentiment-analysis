# Phase 10 - Business Insights Report

## Overall Sentiment Health
- **73.8%** of analyzed reviews are positive, **26.2%** negative.
- This ratio should be tracked over time (weekly/monthly) as a leading indicator
  of customer satisfaction trend -- a sudden drop in positive share is an early
  warning signal worth investigating before it shows up in return-rate or churn data.

## Most Appreciated Themes (from top words in positive reviews)
excellent, great, taste, perfect, love, price, quality, fabulous, wonderful, amazing, fantastic, delicious, fresh, household, like

**Interpretation:** These recurring terms represent what customers consistently
value. Marketing and product teams should double down on messaging and product
attributes that reinforce these themes, and highlight them in listings/ads.

## Frequent Complaint Themes (from top words in negative reviews)
terrible, tasted, arrived, like, disgusting, moldy, review, artificial, stale, bad, bland, awful, worst, ever, bought

**Interpretation:** These terms represent the most common language customers use
when dissatisfied. Product/quality teams should treat spikes in these terms as
triage signals -- e.g. repeated mentions of a specific quality issue across many
reviews for the same product ID is a stronger, earlier signal than waiting for
return-rate data to catch up.

## Recommended Actions
1. **Route high-negative-sentiment reviews to a priority support queue** for
   faster response -- unaddressed negative sentiment is a churn risk.
2. **Feed top complaint terms into the product roadmap review** on a recurring
   (e.g. monthly) cadence, not just when a metric alarm fires.
3. **Use top positive terms in marketing copy** and product descriptions, since
   they reflect the language customers themselves already use to describe value.
4. **Monitor sentiment ratio per product line**, not just in aggregate --
   aggregate sentiment can mask a single underperforming product dragging
   down an otherwise healthy category.
5. **Re-run this pipeline on a recurring schedule** (e.g. weekly) once in
   production, and track sentiment ratio as a time series metric on a dashboard.

## Caveat
This report was generated on synthetic demonstration data.
Re-run this script against the real Amazon Fine Food Reviews dataset (or your
production review stream) before using these specific themes/ratios in an
actual business decision.
