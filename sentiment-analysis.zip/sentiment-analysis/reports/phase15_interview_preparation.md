# Interview Preparation — Sentiment Analysis Project

50 questions across NLP, Python, ML, preprocessing, TF-IDF, Naive Bayes, SVM, statistics, and scenario-based questions, with model answers grounded in this project's implementation.

---

## NLP Fundamentals (Q1-10)

**Q1. What is sentiment analysis and what type of ML problem is it?**
A supervised text classification problem that predicts polarity (positive/negative/neutral) of a piece of text.

**Q2. What's the difference between stemming and lemmatization?**
Stemming applies crude rule-based suffix stripping (fast, can produce non-words, e.g. "studies"→"studi"). Lemmatization uses vocabulary/morphological analysis to return a valid dictionary root (e.g. "studies"→"study"), slower but more accurate.

**Q3. Why is tokenization necessary before vectorization?**
Vectorizers (BoW, TF-IDF) operate on discrete tokens/terms, not raw character strings; tokenization defines the unit of analysis (words, n-grams, subwords).

**Q4. What is a stopword, and why remove it?**
A high-frequency, low-information word ("the", "is", "at"). Removing it reduces dimensionality and noise, though it must be done carefully to avoid deleting negation words.

**Q5. How does this project handle negation, and why does it matter?**
Negation words ("not", "no", "never") are merged with the following token (`not_good`) rather than removed as stopwords, preserving the sentiment-flipping signal that naive stopword removal would destroy.

**Q6. What is an n-gram, and why use bigrams/trigrams in addition to unigrams?**
An n-gram is a contiguous sequence of n tokens. Bigrams/trigrams capture short phrase-level meaning ("not good", "highly recommend") that unigrams alone lose.

**Q7. What's the difference between document-level and aspect-based sentiment analysis (ABSA)?**
Document-level assigns one label per document; ABSA assigns sentiment per mentioned aspect/feature within the same document (e.g. "camera great, battery bad").

**Q8. Why drop 3-star reviews instead of labeling them neutral or forcing them into a class?**
This project is scoped as binary classification; 3-star reviews are genuinely ambiguous, and forcing them into positive/negative would inject label noise that degrades model precision. They were explicitly excluded rather than mislabeled.

**Q9. What is the vocabulary size of a corpus, and why does it matter?**
The count of unique tokens across the corpus. It determines feature-space size for BoW/TF-IDF and directly affects model training time and overfitting risk (very large sparse vocabularies need max_features capping or dimensionality reduction).

**Q10. Why is text data considered "unstructured," and what challenge does that create for ML?**
Text has no fixed schema/columns like tabular data; it must be transformed into numeric feature vectors before any classical ML algorithm can use it — this transformation step (feature extraction) is unique to NLP pipelines.

---

## Text Preprocessing (Q11-16)

**Q11. Why expand contractions before removing punctuation, not after?**
Removing punctuation first turns "don't" into "dont", losing the apostrophe cue needed to correctly expand it to "do not" — order matters in a cleaning pipeline.

**Q12. Why lowercase text before vectorization?**
So "Great" and "great" map to the same feature/token instead of being treated as two different, sparser features.

**Q13. What real-world noise does review text typically contain, and how is each handled in this project?**
HTML tags (`<br />`) → regex-stripped; URLs → regex-stripped; emojis → Unicode-range regex-stripped; numbers → regex-stripped; extra whitespace → collapsed.

**Q14. Why deduplicate on cleaned text rather than raw text?**
Two reviews can differ in raw text (extra whitespace, casing) yet be functionally identical after cleaning; deduping post-cleaning catches these near-duplicates that raw-text deduping misses.

**Q15. What happens if a review becomes an empty string after cleaning, and how is that handled?**
Such rows carry no signal (e.g. a review that was only a URL) and are explicitly dropped by `clean_dataframe`.

**Q16. Why is preprocessing order important overall?**
Each step's regex/rules assume a specific input state (e.g. contractions need apostrophes present); reordering steps can silently corrupt or lose signal, which is why the pipeline is fixed and documented, not applied in arbitrary order.

---

## TF-IDF & Feature Extraction (Q17-24)

**Q17. What does TF-IDF stand for and what does each term measure?**
Term Frequency (how often a word appears in a document) × Inverse Document Frequency (how rare that word is across the whole corpus). It up-weights words distinctive to a document and down-weights globally common words.

**Q18. Why does this project choose TF-IDF over plain Bag of Words?**
BoW treats every word as equally important regardless of how common it is corpus-wide; TF-IDF's IDF term automatically down-weights uninformative common words, giving a stronger, more interpretable signal for classification — verified empirically in Phase 6 via a head-to-head comparison.

**Q19. What's a key limitation of TF-IDF compared to word embeddings (Word2Vec/GloVe)?**
TF-IDF treats each word as an independent dimension with no notion of semantic similarity ("great" and "excellent" are unrelated dimensions), while embeddings place semantically similar words near each other in vector space.

**Q20. Why might averaging Word2Vec vectors for a document lose important information for sentiment analysis specifically?**
Simple averaging discards word order and can dilute the impact of a few strong sentiment-bearing words among many neutral ones — and doesn't naturally represent negation without extra engineering.

**Q21. What does `max_features` control in a TF-IDF/CountVectorizer, and why cap it?**
It caps the vocabulary to the top-N most frequent terms, controlling feature-space size to reduce overfitting risk and training time on high-cardinality vocabularies.

**Q22. What does `min_df=2` mean and why use it?**
Ignore terms appearing in fewer than 2 documents — removes ultra-rare terms (typos, one-off noise) that add dimensionality without generalizable signal.

**Q23. Why use unigrams + bigrams together instead of just unigrams for TF-IDF in this project?**
Bigrams capture short, sentiment-bearing phrases like "not_good" (already merged in cleaning) and "highly recommend" that unigrams alone would represent only as separate, less informative tokens.

**Q24. When would you prefer sentence embeddings (e.g. SBERT) over TF-IDF?**
When raw accuracy matters more than interpretability/compute cost, and you have the infrastructure for transformer inference — flagged as a future enhancement here rather than the MVP choice, to keep the pipeline classical, fast, and explainable.

---

## Naive Bayes (Q25-30)

**Q25. What's the core assumption behind Naive Bayes, and why is it called "naive"?**
It assumes all features (words) are conditionally independent given the class label — an assumption that's almost never literally true for language, hence "naive," yet the model still performs well in practice for text classification.

**Q26. Why is Multinomial Naive Bayes specifically used for text rather than Gaussian Naive Bayes?**
Multinomial NB models discrete word counts/frequencies (well-suited to BoW/TF-IDF features), while Gaussian NB assumes continuous, normally-distributed features — a mismatch for sparse word-count data.

**Q27. What's a key advantage of Naive Bayes for a project like this?**
It's extremely fast to train (even on the full sparse TF-IDF matrix), works well with limited training data, and gives a strong, interpretable baseline.

**Q28. What's a known weakness of Naive Bayes?**
Its independence assumption means it can't capture word interactions/context (e.g. "not good" if not merged specially would be treated as two independent, unrelated signals), and its probability estimates tend to be poorly calibrated even when its class predictions are accurate.

**Q29. How does Laplace/additive smoothing help Naive Bayes?**
It prevents zero probabilities for words unseen in training for a given class, which would otherwise force the entire posterior probability to zero regardless of other evidence.

**Q30. Why might Naive Bayes be well-suited for a fast, resource-constrained production sentiment API?**
Its inference is just a few multiplications over sparse vectors — negligible latency and CPU cost compared to ensemble or deep models, which matters for high-throughput review streams.

---

## SVM & Other Classical Models (Q31-37)

**Q31. What does a linear SVM optimize for in classification?**
It finds the hyperplane that maximizes the margin between classes, which tends to generalize well in high-dimensional, sparse feature spaces like TF-IDF vectors.

**Q32. Why is LinearSVC often preferred over kernel SVM for text classification?**
Text/TF-IDF data is already high-dimensional and often linearly separable in that space, so a linear kernel is usually sufficient and far faster to train than non-linear kernels (RBF, polynomial) at this scale.

**Q33. LinearSVC doesn't expose `predict_proba` — how does this project handle that for the app's confidence score?**
It uses `decision_function` (the signed distance to the separating hyperplane) and passes it through a sigmoid to produce a pseudo-probability for display purposes, explicitly noted as an approximation, not a calibrated probability.

**Q34. Why compare Random Forest and Gradient Boosting alongside linear models for a text task, when tree ensembles aren't the typical NLP default?**
To empirically demonstrate — not just assume — that linear/probabilistic models suit sparse high-dimensional TF-IDF data better; tree ensembles typically need dense, lower-dimensional input to shine, giving a natural comparison point for the write-up.

**Q35. What's the computational trade-off of Gradient Boosting vs. Naive Bayes in this project's results?**
Gradient Boosting took roughly 200x longer to train than Naive Bayes in this pipeline for, on this dataset, no accuracy benefit — a concrete illustration of matching model complexity to problem structure rather than defaulting to the "fanciest" model.

**Q36. Why use `class_weight="balanced"` for Logistic Regression, SVM, and Random Forest here?**
Real e-commerce review data is imbalanced (~76/24 positive/negative); class weighting penalizes misclassifying the minority class more heavily during training, preventing the model from just predicting the majority class.

**Q37. What does `class_weight="balanced"` NOT fix, that resampling techniques like SMOTE would address instead?**
It doesn't change the actual training data distribution — it only reweights the loss function. For severe imbalance, synthetic oversampling (SMOTE) or undersampling may still be needed on top of class weighting.

---

## Model Evaluation & Statistics (Q38-45)

**Q38. Why is accuracy alone a misleading metric on this dataset?**
With ~76% positive class share, a model that always predicts "positive" would score ~76% accuracy while being useless — accuracy doesn't reveal per-class performance.

**Q39. Why does this project select the best model by F1 score rather than accuracy?**
F1 is the harmonic mean of precision and recall, so it penalizes a model that's lopsided toward one class — a much more honest single-number summary under class imbalance than accuracy.

**Q40. What do precision and recall mean specifically for the "positive" class here?**
Precision: of all reviews predicted positive, what fraction truly are positive. Recall: of all truly positive reviews, what fraction did the model correctly find. High precision avoids false alarms; high recall avoids missing real positives.

**Q41. Why would a business care more about recall than precision for detecting NEGATIVE reviews specifically?**
Missing a genuinely negative review (false negative) means a real customer complaint goes unnoticed by support/product teams — often more costly to the business than occasionally over-flagging a neutral-leaning review as negative.

**Q42. What does a confusion matrix show that a single accuracy number doesn't?**
The specific counts of true positives, true negatives, false positives, and false negatives — revealing exactly which class the model struggles with and in which direction its errors skew.

**Q43. Why use 5-fold cross-validation in addition to a single train/test split?**
A single split's metric can be noisy/lucky; cross-validation averages performance across 5 different train/test partitions, giving a more robust estimate of how the model generalizes.

**Q44. What does ROC-AUC measure, and why is it reported alongside precision/recall/F1?**
It measures the model's ability to rank positive examples above negative ones across all possible classification thresholds — useful for understanding threshold-independent discriminative power, complementing the fixed-threshold metrics.

**Q45. If cross-validation F1 std is very low (e.g. near 0) as seen in this project's synthetic-data results, what should you suspect?**
Extremely low variance combined with near-perfect scores often signals the task is too easy / data is too separable (as flagged here — synthetic template-generated text) rather than a genuinely robust, well-generalizing model; this warrants re-validating on real, messier data before trusting the number.

---

## Scenario-Based Questions (Q46-50)

**Q46. Your model gets 99% accuracy on training data but 70% on test data. What's happening, and what would you check first?**
Classic overfitting. First check: model complexity vs. dataset size (e.g. Random Forest/Gradient Boosting with too many estimators on limited data), whether TF-IDF vocabulary size is too large relative to training examples, and whether cross-validation confirms the gap is consistent, not a fluke of one split.

**Q47. A user submits a sarcastic review ("Oh great, ANOTHER broken product, love it") and the model predicts positive. Why might this happen, and how would you address it?**
Classical TF-IDF/BoW models rely on surface-level word polarity ("great", "love") without understanding sarcasm's inverted-context meaning. Addressing it typically requires either a much larger labeled sarcasm-aware training set, richer contextual embeddings (transformer-based models), or a dedicated sarcasm-detection pre-filter — documented here as a known limitation and future enhancement, not silently ignored.

**Q48. Stakeholders want the sentiment model to run in real time on incoming review traffic. What does your model/feature choice enable, and what would you still need to build?**
TF-IDF + Naive Bayes/Logistic Regression both have negligible inference latency, well-suited to real-time scoring. You'd still need to build: a serving layer (API wrapping the saved `.pkl` model+vectorizer), input validation/monitoring, and a pipeline to periodically retrain on fresh labeled data as language/product mix drifts over time.

**Q49. How would you detect that your production sentiment model's performance is degrading over time (data/concept drift)?**
Monitor prediction-confidence distribution and class-balance drift over time against a labeled holdout sample collected periodically; a sustained shift (e.g. confidence dropping, or predicted-positive ratio diverging from a periodically-audited manual sample) signals drift and a need to retrain.

**Q50. If asked to extend this binary model to 3-class (positive/neutral/negative) in an interview, what would change, and what would you warn stakeholders about?**
The `Score==3` filtering rule in Phase 2 would change to *include* 3-star reviews as a "neutral" label instead of dropping them; class imbalance handling would need updating for 3 classes; and precision/recall/F1 would need to be evaluated per-class (e.g. macro-averaged) since "neutral" text is often linguistically the hardest class to separate from mild positive/negative — accuracy on the neutral class specifically would likely be the weakest link and should be flagged upfront, not discovered after deployment.
