# Deployment notes

The Streamlit app requires locally generated model and vectorizer files. The dataset and trained artifacts are not included in this public source package. Generate the synthetic demo data, run the preprocessing and training steps in the root README, then launch `streamlit run app.py`.

Before public deployment, consider authentication, rate limiting, request logging, and monitoring prediction drift.
