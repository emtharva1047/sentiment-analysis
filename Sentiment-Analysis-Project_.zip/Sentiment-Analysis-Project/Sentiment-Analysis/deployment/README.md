# Deployment Notes

The Streamlit application (`../app.py`) is the primary deployment artifact for this project.

## Local run
```bash
pip install -r ../requirements.txt
streamlit run ../app.py
```

## Suggested production hardening (see Project_Report.docx, Section 16: Limitations)
- Add authentication / rate limiting before public exposure
- Add request/response logging and basic monitoring (e.g. prediction confidence drift)
- Containerize (Dockerfile) for consistent deployment across environments
- Consider Streamlit Community Cloud, or a Docker container behind a reverse proxy, for hosting
